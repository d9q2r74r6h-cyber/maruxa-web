import Link from 'next/link';
import { ShoppingBag } from 'lucide-react';
export function Header(){
 return <header className="sticky top-0 z-50 border-b border-maruxa-cafe/10 bg-maruxa-crema/90 backdrop-blur-xl"><div className="contenedor flex h-20 items-center justify-between">
  <Link href="/" className="flex items-center gap-3"><div className="grid h-12 w-12 place-items-center rounded-full bg-maruxa-rojo text-xl font-black text-white shadow-premium">M</div><div><p className="text-xl font-black tracking-tight text-maruxa-vino">Maruxa</p><p className="-mt-1 text-xs uppercase tracking-[.25em] text-maruxa-cafe/70">Panadería</p></div></Link>
  <nav className="hidden items-center gap-7 text-sm font-bold text-maruxa-cafe md:flex"><a href="/#catalogo">Catálogo</a><a href="/#tortas">Tortas</a><a href="/#retiro">Retiro</a><Link href="/admin">Admin</Link></nav>
  <a href="/#catalogo" className="btn-rojo flex items-center gap-2"><ShoppingBag size={18}/> Comprar</a>
 </div></header>
}
